﻿namespace CNIT155_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblUsername = new System.Windows.Forms.Label();
            this.lstShow = new System.Windows.Forms.ListBox();
            this.btnStats = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.groupBox_range = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.radRandom = new System.Windows.Forms.RadioButton();
            this.radUsersinput = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtN1 = new System.Windows.Forms.TextBox();
            this.txtN2 = new System.Windows.Forms.TextBox();
            this.txtN3 = new System.Windows.Forms.TextBox();
            this.cboLevels = new System.Windows.Forms.ComboBox();
            this.lblLevel = new System.Windows.Forms.Label();
            this.btnQuestion = new System.Windows.Forms.Button();
            this.btnSort = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAnswer = new System.Windows.Forms.TextBox();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.btnEnter = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.cboTeam = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lblWarning = new System.Windows.Forms.Label();
            this.groupBox_range.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsername.Location = new System.Drawing.Point(126, 62);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(48, 18);
            this.lblUsername.TabIndex = 0;
            this.lblUsername.Text = "Team:";
            // 
            // lstShow
            // 
            this.lstShow.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstShow.FormattingEnabled = true;
            this.lstShow.ItemHeight = 18;
            this.lstShow.Location = new System.Drawing.Point(22, 207);
            this.lstShow.Name = "lstShow";
            this.lstShow.Size = new System.Drawing.Size(592, 112);
            this.lstShow.TabIndex = 5;
            // 
            // btnStats
            // 
            this.btnStats.Location = new System.Drawing.Point(624, 315);
            this.btnStats.Name = "btnStats";
            this.btnStats.Size = new System.Drawing.Size(126, 28);
            this.btnStats.TabIndex = 7;
            this.btnStats.Text = "Stats";
            this.btnStats.UseVisualStyleBackColor = true;
            this.btnStats.Click += new System.EventHandler(this.btnStats_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(970, 344);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(113, 32);
            this.btnClear.TabIndex = 8;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(968, 381);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(115, 32);
            this.btnExit.TabIndex = 9;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // groupBox_range
            // 
            this.groupBox_range.Controls.Add(this.label3);
            this.groupBox_range.Controls.Add(this.label2);
            this.groupBox_range.Controls.Add(this.radRandom);
            this.groupBox_range.Controls.Add(this.radUsersinput);
            this.groupBox_range.Controls.Add(this.groupBox1);
            this.groupBox_range.Location = new System.Drawing.Point(654, 48);
            this.groupBox_range.Name = "groupBox_range";
            this.groupBox_range.Size = new System.Drawing.Size(428, 218);
            this.groupBox_range.TabIndex = 10;
            this.groupBox_range.TabStop = false;
            this.groupBox_range.Text = "Choices";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(259, 15);
            this.label3.TabIndex = 16;
            this.label3.Text = "Range for Multiplication & Division 1-30";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(257, 15);
            this.label2.TabIndex = 15;
            this.label2.Text = "Range for Addition & Subtraction 1-100";
            // 
            // radRandom
            // 
            this.radRandom.AutoSize = true;
            this.radRandom.Location = new System.Drawing.Point(21, 26);
            this.radRandom.Name = "radRandom";
            this.radRandom.Size = new System.Drawing.Size(170, 19);
            this.radRandom.TabIndex = 1;
            this.radRandom.TabStop = true;
            this.radRandom.Text = "With random numbers";
            this.radRandom.UseVisualStyleBackColor = true;
            // 
            // radUsersinput
            // 
            this.radUsersinput.AutoSize = true;
            this.radUsersinput.Location = new System.Drawing.Point(21, 90);
            this.radUsersinput.Name = "radUsersinput";
            this.radUsersinput.Size = new System.Drawing.Size(141, 19);
            this.radUsersinput.TabIndex = 0;
            this.radUsersinput.TabStop = true;
            this.radUsersinput.Text = "With my numbers";
            this.radUsersinput.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtN1);
            this.groupBox1.Controls.Add(this.txtN2);
            this.groupBox1.Controls.Add(this.txtN3);
            this.groupBox1.Location = new System.Drawing.Point(21, 114);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(383, 83);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Choose Numbers";
            // 
            // txtN1
            // 
            this.txtN1.Location = new System.Drawing.Point(20, 33);
            this.txtN1.Name = "txtN1";
            this.txtN1.Size = new System.Drawing.Size(99, 25);
            this.txtN1.TabIndex = 15;
            this.txtN1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtN2
            // 
            this.txtN2.Location = new System.Drawing.Point(125, 33);
            this.txtN2.Name = "txtN2";
            this.txtN2.Size = new System.Drawing.Size(104, 25);
            this.txtN2.TabIndex = 14;
            this.txtN2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtN3
            // 
            this.txtN3.Location = new System.Drawing.Point(235, 33);
            this.txtN3.Name = "txtN3";
            this.txtN3.Size = new System.Drawing.Size(103, 25);
            this.txtN3.TabIndex = 13;
            this.txtN3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cboLevels
            // 
            this.cboLevels.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLevels.FormattingEnabled = true;
            this.cboLevels.Items.AddRange(new object[] {
            "Addition & Subtraction",
            "Multiplication & Division"});
            this.cboLevels.Location = new System.Drawing.Point(198, 122);
            this.cboLevels.Name = "cboLevels";
            this.cboLevels.Size = new System.Drawing.Size(233, 23);
            this.cboLevels.TabIndex = 11;
            // 
            // lblLevel
            // 
            this.lblLevel.AutoSize = true;
            this.lblLevel.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLevel.Location = new System.Drawing.Point(125, 124);
            this.lblLevel.Name = "lblLevel";
            this.lblLevel.Size = new System.Drawing.Size(64, 18);
            this.lblLevel.TabIndex = 12;
            this.lblLevel.Text = "Levels:";
            // 
            // btnQuestion
            // 
            this.btnQuestion.Location = new System.Drawing.Point(299, 161);
            this.btnQuestion.Name = "btnQuestion";
            this.btnQuestion.Size = new System.Drawing.Size(132, 34);
            this.btnQuestion.TabIndex = 15;
            this.btnQuestion.Text = "Display question";
            this.btnQuestion.UseVisualStyleBackColor = true;
            this.btnQuestion.Click += new System.EventHandler(this.btnAnswer_Click);
            // 
            // btnSort
            // 
            this.btnSort.Location = new System.Drawing.Point(624, 346);
            this.btnSort.Name = "btnSort";
            this.btnSort.Size = new System.Drawing.Size(126, 30);
            this.btnSort.TabIndex = 16;
            this.btnSort.Text = "Sort Rank";
            this.btnSort.UseVisualStyleBackColor = true;
            this.btnSort.Click += new System.EventHandler(this.btnSort_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(36, 81);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(131, 38);
            this.btnSearch.TabIndex = 17;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(67, 40);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(107, 25);
            this.txtSearch.TabIndex = 18;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.btnSearch);
            this.groupBox2.Controls.Add(this.txtSearch);
            this.groupBox2.Location = new System.Drawing.Point(756, 281);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 137);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Search Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // txtAnswer
            // 
            this.txtAnswer.Location = new System.Drawing.Point(90, 360);
            this.txtAnswer.Name = "txtAnswer";
            this.txtAnswer.Size = new System.Drawing.Size(159, 25);
            this.txtAnswer.TabIndex = 20;
            // 
            // lblAnswer
            // 
            this.lblAnswer.AutoSize = true;
            this.lblAnswer.Location = new System.Drawing.Point(26, 360);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(59, 15);
            this.lblAnswer.TabIndex = 21;
            this.lblAnswer.Text = "Answer:";
            // 
            // btnEnter
            // 
            this.btnEnter.Location = new System.Drawing.Point(273, 357);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(115, 26);
            this.btnEnter.TabIndex = 22;
            this.btnEnter.Text = "Enter";
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(26, 390);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(536, 15);
            this.label4.TabIndex = 23;
            this.label4.Text = "*If the answer is not an integer, please enter your answer of just the integer pa" +
    "rt.";
            // 
            // cboTeam
            // 
            this.cboTeam.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTeam.FormattingEnabled = true;
            this.cboTeam.Items.AddRange(new object[] {
            "CNIT",
            "Cybersecurity",
            "SAAD",
            "NET"});
            this.cboTeam.Location = new System.Drawing.Point(199, 59);
            this.cboTeam.Name = "cboTeam";
            this.cboTeam.Size = new System.Drawing.Size(232, 23);
            this.cboTeam.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(25, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(360, 22);
            this.label5.TabIndex = 25;
            this.label5.Text = "CIT DEPARTMENT MATH BATTLE";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(26, 406);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 15);
            this.label6.TabIndex = 26;
            this.label6.Text = "Do not round up!!";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(624, 281);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(126, 29);
            this.button1.TabIndex = 27;
            this.button1.Text = "Past Questions";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(198, 88);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(233, 25);
            this.txtName.TabIndex = 28;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(126, 90);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 18);
            this.label7.TabIndex = 29;
            this.label7.Text = "Name:";
            // 
            // lblWarning
            // 
            this.lblWarning.AutoSize = true;
            this.lblWarning.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWarning.Location = new System.Drawing.Point(789, 18);
            this.lblWarning.Name = "lblWarning";
            this.lblWarning.Size = new System.Drawing.Size(312, 18);
            this.lblWarning.TabIndex = 30;
            this.lblWarning.Text = "*Each team must play at least one game";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1114, 455);
            this.Controls.Add(this.lblWarning);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cboTeam);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.lblAnswer);
            this.Controls.Add(this.txtAnswer);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnSort);
            this.Controls.Add(this.btnQuestion);
            this.Controls.Add(this.lblLevel);
            this.Controls.Add(this.cboLevels);
            this.Controls.Add(this.groupBox_range);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnStats);
            this.Controls.Add(this.lstShow);
            this.Controls.Add(this.lblUsername);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Math Game";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.groupBox_range.ResumeLayout(false);
            this.groupBox_range.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.ListBox lstShow;
        private System.Windows.Forms.Button btnStats;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.GroupBox groupBox_range;
        private System.Windows.Forms.RadioButton radRandom;
        private System.Windows.Forms.RadioButton radUsersinput;
        private System.Windows.Forms.ComboBox cboLevels;
        private System.Windows.Forms.Label lblLevel;
        private System.Windows.Forms.TextBox txtN3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtN1;
        private System.Windows.Forms.TextBox txtN2;
        private System.Windows.Forms.Button btnQuestion;
        private System.Windows.Forms.Button btnSort;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAnswer;
        private System.Windows.Forms.Label lblAnswer;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cboTeam;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblWarning;
    }
}

