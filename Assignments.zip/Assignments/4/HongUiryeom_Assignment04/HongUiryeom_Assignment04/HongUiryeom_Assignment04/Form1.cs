﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/*=========================================================
* Uiryeom Hong
* uhong@purdue.edu
* CNIT155 Assignment04
* Lab Section: Thurs. 11:30
* Program Description:  This is a simple easy math game. When a user put his/her own inputs, the system will automatically give the user random two numbers.
* If the user put simple small numbers, the random numbers are going to be small and simple. However, if the user put bigger numbers for inputs, then the 
* random numbers are going to be bigger. With the random numbers, the user is going to play simple addition math game.
* The user is going to have a message box that is going to tell if the user's answer is right or wrong. The system will keep track of how many answers
* the user has right and how many answers the user has wrong. The system will automatically give the user a compliment based on how many answers the user have right.  
*
* Academic Honesty: 
*	I attest that this is my original work.
*	I have not used unauthorized source code, either modified or unmodified.
*	I have not given other fellow student(s) access to my program.
*=========================================================== */

namespace HongUiryeom_Assignment04
{
	public partial class Form1 : Form
	{

        public Form1()
		{
			InitializeComponent();
		}

		private void Form1_Load(object sender, EventArgs e)
		{

		}

		private void btnExit_Click(object sender, EventArgs e)
		{
			Close();
		}
    
        private void btnPlay_Click(object sender, EventArgs e)
		{
            /*******************************
             *Declare three int variables to store the user’s input. 
             *Declare two int variables to store two random numbers (**).
             *Declare other variables as needed.
             *Store the user’s input in corresponding variables. 
             *Add up the three input numbers, store the sum in declared variable.
             *Use a cascading if / else if statement to check the sum and determine the difficulty of the math problem to be presented:
             *If the sum of the three input numbers is greater than or equal to 50 (difficulty level high)
             *Generate two random numbers between 50 and 100, both inclusive (See **). 
             *Display the numbers in the textboxes on the right provided for N1 and N2.
             * 
             *Otherwise, if the sum is less than 50 but greater than or equal to 20 (Moderate problem)
             *Generate two random numbers between 20 and 50, both inclusive.
             *Display the numbers in textboxes for N1 and N2.
             *Otherwise, ( Easy problem)
             *Generate two random numbers between 1 and 10, both inclusive.
             *Display the numbers in textboxes for N1 and N2.
             *********************************************/

            int Input1;
			int Input2;
			int Input3;

            Random rnum = new Random();

            String difficulty;

			Input1 = int.Parse(txtInput1.Text);
			Input2 = int.Parse(txtInput2.Text);
			Input3 = int.Parse(txtInput3.Text);

            int sum = (Input1 + Input2 + Input3);

            if (sum >= 50)
            {
                difficulty = "High";
            }
            else if (sum >= 20 && sum < 50)
            {
                difficulty = "Moderate";
            }
            else
            {
                difficulty = "Easy";
            }
       
            if (difficulty.Equals("High"))
            {
              
                int N1 = rnum.Next(50, 100);
                int N2 = rnum.Next(50, 100);
                txtN1.Text = N1.ToString();
                txtN2.Text = N2.ToString();
            }
            else if (difficulty.Equals("Moderate"))
            {
                int N1 = rnum.Next(20, 50);
                txtN1.Text = N1.ToString();
                int N2 = rnum.Next(20, 50);
                txtN2.Text = N2.ToString();
            }
            else
            {
                int N1 = rnum.Next(1, 10);
                txtN1.Text = N1.ToString();
                int N2 = rnum.Next(1, 10);
                txtN2.Text = N2.ToString();
            }

		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{

		}

		private void textBox2_TextChanged(object sender, EventArgs e)
		{

		}

		private void btnClear_Click(object sender, EventArgs e)
		{
			txtOutput.Text = "";
			txtInput1.Text = "";
			txtInput2.Text = "";
			txtInput3.Text = "";
			txtN1.Text = "";
			txtN2.Text = "";
            txtSum.Text = "";
			txtInput1.Focus();
		}

        int rCount;
        int wCount;
        private void btnShowStats_Click(object sender, EventArgs e)
        {
            txtOutput.Text = "";
            txtInput1.Text = "";
            txtInput2.Text = "";
            txtInput3.Text = "";
            txtN1.Text = "";
            txtN2.Text = "";
            txtSum.Text = "";
            if (rCount > wCount)
            {
                txtOutput.Text = "Number of correct answers = " + rCount.ToString() + "\r\n" +
                "Number of wrong answers = " + wCount.ToString() + "\r\n" +
                "Good job!";
            }
            else
            {
                txtOutput.Text = "Number of correct answers = " + rCount.ToString() + "\r\n" +
                "Number of wrong answers = " + wCount.ToString() + "\r\n" +
                "Worder Harder.";
            } 

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            int N1;
            int N2;

            N1 = int.Parse(txtN1.Text);
            N2 = int.Parse(txtN2.Text);

            int sum;
            sum = int.Parse(txtSum.Text);

            int answer = (N1 + N2);

            if (sum == answer)
            {
                MessageBox.Show("That is right!!");
                rCount = rCount + 1;
            }
            else if (sum != answer)
            {
                MessageBox.Show("Sorry, You missed it - try again");
                wCount = wCount + 1;
            }
        }
    }
}
