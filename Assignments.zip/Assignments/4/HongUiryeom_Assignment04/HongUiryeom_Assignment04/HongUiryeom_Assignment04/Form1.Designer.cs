﻿namespace HongUiryeom_Assignment04
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnShowStats = new System.Windows.Forms.Button();
            this.btnPlay = new System.Windows.Forms.Button();
            this.txtInput3 = new System.Windows.Forms.TextBox();
            this.txtInput2 = new System.Windows.Forms.TextBox();
            this.txtInput1 = new System.Windows.Forms.TextBox();
            this.lblInput3 = new System.Windows.Forms.Label();
            this.lblInput2 = new System.Windows.Forms.Label();
            this.lblInput1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtSum = new System.Windows.Forms.TextBox();
            this.lblplus = new System.Windows.Forms.Label();
            this.txtN2 = new System.Windows.Forms.TextBox();
            this.txtN1 = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.lblSum = new System.Windows.Forms.Label();
            this.lblN2 = new System.Windows.Forms.Label();
            this.lblN1 = new System.Windows.Forms.Label();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnShowStats);
            this.groupBox1.Controls.Add(this.btnPlay);
            this.groupBox1.Controls.Add(this.txtInput3);
            this.groupBox1.Controls.Add(this.txtInput2);
            this.groupBox1.Controls.Add(this.txtInput1);
            this.groupBox1.Controls.Add(this.lblInput3);
            this.groupBox1.Controls.Add(this.lblInput2);
            this.groupBox1.Controls.Add(this.lblInput1);
            this.groupBox1.Location = new System.Drawing.Point(33, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(169, 190);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "User Input:";
            // 
            // btnShowStats
            // 
            this.btnShowStats.Location = new System.Drawing.Point(83, 149);
            this.btnShowStats.Name = "btnShowStats";
            this.btnShowStats.Size = new System.Drawing.Size(75, 23);
            this.btnShowStats.TabIndex = 7;
            this.btnShowStats.Text = "Show Stats";
            this.btnShowStats.UseVisualStyleBackColor = true;
            this.btnShowStats.Click += new System.EventHandler(this.btnShowStats_Click);
            // 
            // btnPlay
            // 
            this.btnPlay.Location = new System.Drawing.Point(83, 119);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(75, 23);
            this.btnPlay.TabIndex = 6;
            this.btnPlay.Text = "Play";
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // txtInput3
            // 
            this.txtInput3.Location = new System.Drawing.Point(52, 78);
            this.txtInput3.Name = "txtInput3";
            this.txtInput3.Size = new System.Drawing.Size(100, 20);
            this.txtInput3.TabIndex = 5;
            // 
            // txtInput2
            // 
            this.txtInput2.Location = new System.Drawing.Point(52, 52);
            this.txtInput2.Name = "txtInput2";
            this.txtInput2.Size = new System.Drawing.Size(100, 20);
            this.txtInput2.TabIndex = 4;
            // 
            // txtInput1
            // 
            this.txtInput1.Location = new System.Drawing.Point(52, 26);
            this.txtInput1.Name = "txtInput1";
            this.txtInput1.Size = new System.Drawing.Size(100, 20);
            this.txtInput1.TabIndex = 3;
            // 
            // lblInput3
            // 
            this.lblInput3.AutoSize = true;
            this.lblInput3.Location = new System.Drawing.Point(6, 81);
            this.lblInput3.Name = "lblInput3";
            this.lblInput3.Size = new System.Drawing.Size(40, 13);
            this.lblInput3.TabIndex = 2;
            this.lblInput3.Text = "Input3:";
            // 
            // lblInput2
            // 
            this.lblInput2.AutoSize = true;
            this.lblInput2.Location = new System.Drawing.Point(7, 55);
            this.lblInput2.Name = "lblInput2";
            this.lblInput2.Size = new System.Drawing.Size(40, 13);
            this.lblInput2.TabIndex = 1;
            this.lblInput2.Text = "Input2:";
            // 
            // lblInput1
            // 
            this.lblInput1.AutoSize = true;
            this.lblInput1.Location = new System.Drawing.Point(7, 29);
            this.lblInput1.Name = "lblInput1";
            this.lblInput1.Size = new System.Drawing.Size(40, 13);
            this.lblInput1.TabIndex = 0;
            this.lblInput1.Text = "Input1:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtSum);
            this.groupBox2.Controls.Add(this.lblplus);
            this.groupBox2.Controls.Add(this.txtN2);
            this.groupBox2.Controls.Add(this.txtN1);
            this.groupBox2.Controls.Add(this.btnSubmit);
            this.groupBox2.Controls.Add(this.lblSum);
            this.groupBox2.Controls.Add(this.lblN2);
            this.groupBox2.Controls.Add(this.lblN1);
            this.groupBox2.Location = new System.Drawing.Point(245, 37);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 190);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Math Problem:";
            // 
            // txtSum
            // 
            this.txtSum.Location = new System.Drawing.Point(63, 101);
            this.txtSum.Name = "txtSum";
            this.txtSum.Size = new System.Drawing.Size(100, 20);
            this.txtSum.TabIndex = 7;
            this.txtSum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblplus
            // 
            this.lblplus.AutoSize = true;
            this.lblplus.Location = new System.Drawing.Point(106, 55);
            this.lblplus.Name = "lblplus";
            this.lblplus.Size = new System.Drawing.Size(13, 13);
            this.lblplus.TabIndex = 6;
            this.lblplus.Text = "+";
            // 
            // txtN2
            // 
            this.txtN2.Location = new System.Drawing.Point(63, 75);
            this.txtN2.Name = "txtN2";
            this.txtN2.ReadOnly = true;
            this.txtN2.Size = new System.Drawing.Size(100, 20);
            this.txtN2.TabIndex = 5;
            this.txtN2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtN2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txtN1
            // 
            this.txtN1.Location = new System.Drawing.Point(63, 29);
            this.txtN1.Name = "txtN1";
            this.txtN1.ReadOnly = true;
            this.txtN1.Size = new System.Drawing.Size(100, 20);
            this.txtN1.TabIndex = 4;
            this.txtN1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtN1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(106, 135);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 3;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // lblSum
            // 
            this.lblSum.AutoSize = true;
            this.lblSum.Location = new System.Drawing.Point(22, 101);
            this.lblSum.Name = "lblSum";
            this.lblSum.Size = new System.Drawing.Size(31, 13);
            this.lblSum.TabIndex = 2;
            this.lblSum.Text = "Sum:";
            // 
            // lblN2
            // 
            this.lblN2.AutoSize = true;
            this.lblN2.Location = new System.Drawing.Point(29, 78);
            this.lblN2.Name = "lblN2";
            this.lblN2.Size = new System.Drawing.Size(24, 13);
            this.lblN2.TabIndex = 1;
            this.lblN2.Text = "N2:";
            // 
            // lblN1
            // 
            this.lblN1.AutoSize = true;
            this.lblN1.Location = new System.Drawing.Point(29, 29);
            this.lblN1.Name = "lblN1";
            this.lblN1.Size = new System.Drawing.Size(27, 13);
            this.lblN1.TabIndex = 0;
            this.lblN1.Text = "N1: ";
            // 
            // txtOutput
            // 
            this.txtOutput.Location = new System.Drawing.Point(33, 233);
            this.txtOutput.Multiline = true;
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.ReadOnly = true;
            this.txtOutput.Size = new System.Drawing.Size(412, 166);
            this.txtOutput.TabIndex = 2;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(289, 419);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(370, 419);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 471);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txtOutput);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.Text = "HongUiryeom_Assignment04";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button btnShowStats;
		private System.Windows.Forms.Button btnPlay;
		private System.Windows.Forms.TextBox txtInput3;
		private System.Windows.Forms.TextBox txtInput2;
		private System.Windows.Forms.TextBox txtInput1;
		private System.Windows.Forms.Label lblInput3;
		private System.Windows.Forms.Label lblInput2;
		private System.Windows.Forms.Label lblInput1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Button btnSubmit;
		private System.Windows.Forms.Label lblSum;
		private System.Windows.Forms.Label lblN2;
		private System.Windows.Forms.Label lblN1;
		private System.Windows.Forms.TextBox txtOutput;
		private System.Windows.Forms.Button btnClear;
		private System.Windows.Forms.Button btnExit;
		private System.Windows.Forms.TextBox txtN2;
		private System.Windows.Forms.TextBox txtN1;
		private System.Windows.Forms.Label lblplus;
		private System.Windows.Forms.TextBox txtSum;
	}
}

