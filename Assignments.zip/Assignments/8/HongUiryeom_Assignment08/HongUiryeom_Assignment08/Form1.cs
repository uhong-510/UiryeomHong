﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*=========================================================
* Uiryeom Hong
* uhong@purdue.edu
* CNIT155 Assignment08
* Lab Section: Thurs. 11:30
* Program Description: The program displays all the students' names, GPAs, and what department each student is in 
* according to the user's input. It also provides what is the average of GPAs of all students that the user has put, 
* the highest GPA by who in what department according to the list of students, 
* and the lowest GPA by who in what department among the students. It can also shows how many students have been processed. 
* Academic Honesty: 
*	I attest that this is my original work.
*	I have not used unauthorized source code, either modified or unmodified.
*	I have not given other fellow student(s) access to my program.
*=========================================================== */

namespace HongUiryeom_Assignment08
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Class Scope Declarations
        private const int cSize = 20;
        private string[] mName = new string[20];
        private double[] mGPA = new double[20];
        private string[] mDepartment = new string[20];
        private int mIndex = 0;

        //Helper Method
        private bool ValidateInput()
        {
            //Full Name
            if (txtFullName.Text == "")
            {
                DisplayMessageOK("Please enter your name.");
                txtFullName.Focus();
                return false;
            }
            if (txtFullName.Text.IndexOf(" ") == -1)
            {
                DisplayMessageOK("Please enter a full name.");
                txtFullName.Focus();
                return false;
            }
            //GPA
            double GPA;
            if (double.TryParse(txtGPA.Text, out GPA) == false)
            {
                DisplayMessageOK("GPA must be a real number.");
                txtGPA.Focus();
                return false;
            }
            if (0 > GPA || GPA > 4.00)
            {
                DisplayMessageOK("Valid range for GPA is 0 to 4.00.");
                txtGPA.Focus();
                return false;
            }
            //Combobox
            if (cboDepartment.SelectedIndex == -1)
            {
                DisplayMessageOK("One of the departments must be selected.");
                cboDepartment.Focus();
                return false;
            }

            return true;
        }

        //messagebox
        private void DisplayMessageOK(string msg)
        {
            MessageBox.Show(msg, Text, MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        //max
        private int FindMax(double [] mGPA, int mIndex)
        {
            double max = mGPA[0];
            int maxIndex = 0;
            max = mGPA[0];
            for (int ctr = 0; ctr < mIndex; ctr++)
            {
                if (mGPA[ctr] > max)
                {
                    max = mGPA[ctr];
                    maxIndex = ctr;
                }
            }


            return maxIndex;
        }
        
        //min
        private int FindMin(double [] mGPA, int mIndex)
        {
            double min = mGPA[0];
            int minIndex = 0;
            for (int ctr = 0; ctr < mIndex; ctr++)
            {
                if (mGPA[ctr] < min)
                {
                    min = mGPA[ctr];
                    minIndex = ctr;
                }
            }

            return minIndex;
        }

        //average
        private double ComputeAvg()
        {
            int ctr;
            double sum = 0, average;

            for (ctr = 0; ctr < mIndex; ctr++)
            {
                sum = sum + mGPA[ctr];
            }

            average = sum / mIndex;

            return average;
        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            if (ValidateInput() == false)
            {
                return;
            }

            mName[mIndex] = txtFullName.Text;
            mGPA[mIndex] = double.Parse(txtGPA.Text);
            mDepartment[mIndex] = cboDepartment.Text;

            mIndex++;
            if (mIndex == cSize)
            {
                DisplayMessageOK("Array is full.");
                btnEnter.Enabled = false;
            }

            txtFullName.Clear();
            txtGPA.Clear();
            cboDepartment.SelectedIndex = -1;
            txtFullName.Focus();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            lstOutput.Items.Clear();

            if (mIndex == 0)
            {
                DisplayMessageOK("Array is Empty");
                return;
            }

            lstOutput.Items.Add("Full Name".PadRight(15) + "GPA".PadRight(10) + "Department");
            lstOutput.Items.Add("==========================================");

            for (int ctr = 0; ctr < mIndex; ctr++)
            {
                lstOutput.Items.Add(mName[ctr].PadRight(15) + mGPA[ctr].ToString("n").PadRight(10) + mDepartment[ctr]);
            }

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtFullName.Clear();
            txtGPA.Clear();
            cboDepartment.SelectedIndex = -1;
            lstOutput.Items.Clear();
            txtFullName.Focus();
        }

        private void btnStats_Click(object sender, EventArgs e)
        {
            if (mIndex == 0)
            {
                DisplayMessageOK("Array is Empty");
                return;
            }

            lstOutput.Items.Clear();

            double average = ComputeAvg();
            double max = FindMax(mGPA, mIndex);
            double min = FindMin(mGPA, mIndex);
            int maxIndex = FindMax(mGPA, mIndex);
            int minIndex = FindMin(mGPA, mIndex);


            lstOutput.Items.Add("Number of Students: " + mIndex);
            lstOutput.Items.Add("Average GPA: " + average.ToString("N"));
            lstOutput.Items.Add("Max GPA: " + mGPA[maxIndex].ToString("N"));
            lstOutput.Items.Add("By Student: ".PadLeft(15) + mName[maxIndex] + " , " + "Department: " + mDepartment[maxIndex]);
            lstOutput.Items.Add("Min GPA: " + mGPA[minIndex].ToString("N"));
            lstOutput.Items.Add("By Student: ".PadLeft(15) + mName[minIndex] + " , " + "Department: " + mDepartment[minIndex]);
        }
    }
}
