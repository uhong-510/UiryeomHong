﻿namespace HongUiryeom_Assignment09
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.lblScore = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtScore = new System.Windows.Forms.TextBox();
            this.checkBox_Dean = new System.Windows.Forms.CheckBox();
            this.groupBox_SortOrder = new System.Windows.Forms.GroupBox();
            this.btnSort = new System.Windows.Forms.Button();
            this.radDESC = new System.Windows.Forms.RadioButton();
            this.radASC = new System.Windows.Forms.RadioButton();
            this.btnEnter = new System.Windows.Forms.Button();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.lstOutput = new System.Windows.Forms.ListBox();
            this.btnDeanList = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.groupBox_SortOrder.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(53, 50);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(48, 15);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name:";
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Location = new System.Drawing.Point(50, 100);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(51, 15);
            this.lblScore.TabIndex = 1;
            this.lblScore.Text = "Score:";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(122, 47);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(153, 25);
            this.txtName.TabIndex = 2;
            // 
            // txtScore
            // 
            this.txtScore.Location = new System.Drawing.Point(122, 97);
            this.txtScore.Name = "txtScore";
            this.txtScore.Size = new System.Drawing.Size(153, 25);
            this.txtScore.TabIndex = 3;
            // 
            // checkBox_Dean
            // 
            this.checkBox_Dean.AutoSize = true;
            this.checkBox_Dean.Location = new System.Drawing.Point(138, 146);
            this.checkBox_Dean.Name = "checkBox_Dean";
            this.checkBox_Dean.Size = new System.Drawing.Size(112, 19);
            this.checkBox_Dean.TabIndex = 4;
            this.checkBox_Dean.Text = "Dean\'s List?";
            this.checkBox_Dean.UseVisualStyleBackColor = true;
            // 
            // groupBox_SortOrder
            // 
            this.groupBox_SortOrder.Controls.Add(this.btnSort);
            this.groupBox_SortOrder.Controls.Add(this.radDESC);
            this.groupBox_SortOrder.Controls.Add(this.radASC);
            this.groupBox_SortOrder.Location = new System.Drawing.Point(387, 25);
            this.groupBox_SortOrder.Name = "groupBox_SortOrder";
            this.groupBox_SortOrder.Size = new System.Drawing.Size(180, 164);
            this.groupBox_SortOrder.TabIndex = 5;
            this.groupBox_SortOrder.TabStop = false;
            this.groupBox_SortOrder.Text = "Sort Order";
            // 
            // btnSort
            // 
            this.btnSort.Location = new System.Drawing.Point(33, 109);
            this.btnSort.Name = "btnSort";
            this.btnSort.Size = new System.Drawing.Size(114, 31);
            this.btnSort.TabIndex = 2;
            this.btnSort.Text = "&Sort";
            this.btnSort.UseVisualStyleBackColor = true;
            this.btnSort.Click += new System.EventHandler(this.btnSort_Click);
            // 
            // radDESC
            // 
            this.radDESC.AutoSize = true;
            this.radDESC.Location = new System.Drawing.Point(33, 66);
            this.radDESC.Name = "radDESC";
            this.radDESC.Size = new System.Drawing.Size(105, 19);
            this.radDESC.TabIndex = 1;
            this.radDESC.TabStop = true;
            this.radDESC.Text = "Descending";
            this.radDESC.UseVisualStyleBackColor = true;
            // 
            // radASC
            // 
            this.radASC.AutoSize = true;
            this.radASC.Location = new System.Drawing.Point(33, 28);
            this.radASC.Name = "radASC";
            this.radASC.Size = new System.Drawing.Size(96, 19);
            this.radASC.TabIndex = 0;
            this.radASC.TabStop = true;
            this.radASC.Text = "Ascending";
            this.radASC.UseVisualStyleBackColor = true;
            // 
            // btnEnter
            // 
            this.btnEnter.Location = new System.Drawing.Point(51, 190);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(102, 27);
            this.btnEnter.TabIndex = 6;
            this.btnEnter.Text = "&Enter";
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(188, 190);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(105, 27);
            this.btnDisplay.TabIndex = 7;
            this.btnDisplay.Text = "&Display";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // lstOutput
            // 
            this.lstOutput.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstOutput.FormattingEnabled = true;
            this.lstOutput.ItemHeight = 18;
            this.lstOutput.Location = new System.Drawing.Point(26, 242);
            this.lstOutput.Name = "lstOutput";
            this.lstOutput.Size = new System.Drawing.Size(343, 148);
            this.lstOutput.TabIndex = 8;
            this.lstOutput.SelectedIndexChanged += new System.EventHandler(this.lstOutput_SelectedIndexChanged);
            // 
            // btnDeanList
            // 
            this.btnDeanList.Location = new System.Drawing.Point(411, 239);
            this.btnDeanList.Name = "btnDeanList";
            this.btnDeanList.Size = new System.Drawing.Size(118, 30);
            this.btnDeanList.TabIndex = 9;
            this.btnDeanList.Text = "Dean\'s &List";
            this.btnDeanList.UseVisualStyleBackColor = true;
            this.btnDeanList.Click += new System.EventHandler(this.btnDeanList_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(411, 287);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(118, 30);
            this.btnClear.TabIndex = 10;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(411, 339);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(118, 30);
            this.btnExit.TabIndex = 11;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(597, 418);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnDeanList);
            this.Controls.Add(this.lstOutput);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.groupBox_SortOrder);
            this.Controls.Add(this.checkBox_Dean);
            this.Controls.Add(this.txtScore);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.lblName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.Text = "HongUiryeom_Assignment09";
            this.groupBox_SortOrder.ResumeLayout(false);
            this.groupBox_SortOrder.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtScore;
        private System.Windows.Forms.CheckBox checkBox_Dean;
        private System.Windows.Forms.GroupBox groupBox_SortOrder;
        private System.Windows.Forms.Button btnSort;
        private System.Windows.Forms.RadioButton radDESC;
        private System.Windows.Forms.RadioButton radASC;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.ListBox lstOutput;
        private System.Windows.Forms.Button btnDeanList;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
    }
}

