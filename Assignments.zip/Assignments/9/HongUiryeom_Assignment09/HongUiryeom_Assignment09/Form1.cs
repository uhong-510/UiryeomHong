﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*=========================================================
* Uiryeom Hong
* uhong@purdue.edu
* CNIT155 Assignment09
* Lab Section: Thurs. 11:30
* Program Description: The program shows all the students' names, scores, and if the student is in Dean's list according to the user's inputs. 
* If the user wants sort the lists in ascedning order, all the inputs in listbox will displayed in ascending order and displayed in reverse order for
* descending order. The program can also show those students who are in Dean's lists with their scores and names.
* Academic Honesty: 
*	I attest that this is my original work.
*	I have not used unauthorized source code, either modified or unmodified.
*	I have not given other fellow student(s) access to my program.
*=========================================================== */

namespace HongUiryeom_Assignment09
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Class Scope Declarations
        private const int cSize = 20;
        private string[] mName = new string[cSize];
        private int[] mScore = new int[cSize];
        private bool[] mDean = new bool[cSize];
        private int mIndex = 0;

        //Helper Method
        //ValidateInput
        private bool ValidateInput()
        {
            if (txtName.Text == "")
            {
                DisplayMessage("Please enter your name.");
                txtName.Focus();
                return false;
            }
            if (txtName.Text.IndexOf(" ") == -1)
            {
                DisplayMessage("Please enter your full name.");
                txtName.Focus();
                return false;
            }
            int score = 0;
            if (int.TryParse(txtScore.Text, out score) == false)
            {
                DisplayMessage("Score must be a whole number.");
                txtScore.Focus();
                return false;
            }
            if (score < 0 || 100 < score)
            {
                DisplayMessage("Socre must be between 0 and 100.");
                txtScore.Focus();
                return false;
            }
            return true;
        }
        //ClearInput
        private void ClearInput()
        {
            txtName.Clear();
            txtScore.Clear();
            radASC.Checked = false;
            radDESC.Checked = false;
            checkBox_Dean.Checked = false;
            txtName.Focus();
        }
        //Message Box
        private void DisplayMessage(string message)
        {
            MessageBox.Show(message, Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
        //RefreshListBox
        private void RefreshListBox()
        {
            lstOutput.Items.Clear();

            lstOutput.Items.Add("Name".PadRight(15) + "Score".PadRight(15) + "Dean's List");
            lstOutput.Items.Add("===========================================");

            for (int ctr = 0; ctr < mIndex; ctr++)
            {
                lstOutput.Items.Add(mName[ctr].PadRight(15) + mScore[ctr].ToString("").PadRight(15) + mDean[ctr]);
            }
        }
        //MakeCopy
        private void MakeCopy(int[] mScore, int[] copy_arr, int mindex)
        {
            int ctr;
            for (ctr = 0; ctr < mIndex; ctr++)
            {
                copy_arr[ctr] = mScore[ctr];
            }
        }


        private void btnEnter_Click(object sender, EventArgs e)
        {
            if (ValidateInput() == false)
            {
                return;
            }

            mName[mIndex] = txtName.Text;
            mScore[mIndex] = int.Parse(txtScore.Text);

            if (checkBox_Dean.Checked == true)
            {
                mDean[mIndex] = true;
            }
            else
            {
                mDean[mIndex] = false;
            }

            mIndex++;

            if (mIndex == cSize)
            {
                DisplayMessage("Array is full.");
                btnEnter.Enabled = false;
            }

            ClearInput();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            if (mIndex == 0)
            {
                DisplayMessage("Array is Empty.");
                return;
            }

            lstOutput.Items.Clear();

            RefreshListBox();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearInput();
            lstOutput.Items.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            int[] copy_arr = new int[cSize];

            if (radASC.Checked == false && radDESC.Checked == false)
            {
                DisplayMessage("One of the orders must be selected.");
                return;
            }

            MakeCopy(mScore, copy_arr, mIndex);

            if (radASC.Checked == true)
            {
                lstOutput.Items.Clear();
                Array.Sort(mScore, mName, 0, mIndex);
                Array.Sort(copy_arr, mDean, 0, mIndex);
            }
            else
            {
                lstOutput.Items.Clear();
                Array.Reverse(mScore, 0, mIndex);
            }

            RefreshListBox();
        }

        private void lstOutput_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index;
            index = (lstOutput.SelectedIndex - 2);
            if (index <= -1)
            {
                DisplayMessage("Please select a right person.");
                return;
            }

            txtName.Text = mName[index];
            txtScore.Text = mScore[index].ToString();
        }

        private void btnDeanList_Click(object sender, EventArgs e)
        { 

            lstOutput.Items.Clear();

            int ctr;

            bool flag = false;                                      

            lstOutput.Items.Add("People in Dean's List:");
            lstOutput.Items.Add("Name".PadRight(15) + "Score".PadRight(15) + "Dean's List");
            lstOutput.Items.Add("===========================================");

            for (ctr = 0; ctr < mIndex; ctr++)
            {
                if (mDean[ctr] == true) 
                {
                    flag = true;
                    lstOutput.Items.Add(mName[ctr].PadRight(15)+ mScore[ctr].ToString("").PadRight(15) + mDean[ctr].ToString());
                    break;
                }
            }
            if (flag == false)
            {
                DisplayMessage("Search failed!");
            }
        }
    }
}
