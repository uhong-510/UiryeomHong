﻿namespace HongUiryeom_Assignment10
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.lblGPA = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtGPA = new System.Windows.Forms.TextBox();
            this.groupBox_Focus = new System.Windows.Forms.GroupBox();
            this.radSystem = new System.Windows.Forms.RadioButton();
            this.radCyber = new System.Windows.Forms.RadioButton();
            this.radNET = new System.Windows.Forms.RadioButton();
            this.radCIT = new System.Windows.Forms.RadioButton();
            this.btnEnter = new System.Windows.Forms.Button();
            this.lstOutput = new System.Windows.Forms.ListBox();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.btnStats = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.groupBox_Focus.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(26, 68);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(48, 15);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name:";
            // 
            // lblGPA
            // 
            this.lblGPA.AutoSize = true;
            this.lblGPA.Location = new System.Drawing.Point(32, 115);
            this.lblGPA.Name = "lblGPA";
            this.lblGPA.Size = new System.Drawing.Size(42, 15);
            this.lblGPA.TabIndex = 1;
            this.lblGPA.Text = "GPA:";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(85, 63);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(205, 25);
            this.txtName.TabIndex = 0;
            // 
            // txtGPA
            // 
            this.txtGPA.Location = new System.Drawing.Point(85, 112);
            this.txtGPA.Name = "txtGPA";
            this.txtGPA.Size = new System.Drawing.Size(205, 25);
            this.txtGPA.TabIndex = 3;
            // 
            // groupBox_Focus
            // 
            this.groupBox_Focus.Controls.Add(this.radSystem);
            this.groupBox_Focus.Controls.Add(this.radCyber);
            this.groupBox_Focus.Controls.Add(this.radNET);
            this.groupBox_Focus.Controls.Add(this.radCIT);
            this.groupBox_Focus.Location = new System.Drawing.Point(337, 27);
            this.groupBox_Focus.Name = "groupBox_Focus";
            this.groupBox_Focus.Size = new System.Drawing.Size(175, 169);
            this.groupBox_Focus.TabIndex = 4;
            this.groupBox_Focus.TabStop = false;
            this.groupBox_Focus.Text = "Focus";
            // 
            // radSystem
            // 
            this.radSystem.AutoSize = true;
            this.radSystem.Location = new System.Drawing.Point(31, 136);
            this.radSystem.Name = "radSystem";
            this.radSystem.Size = new System.Drawing.Size(77, 19);
            this.radSystem.TabIndex = 3;
            this.radSystem.TabStop = true;
            this.radSystem.Text = "System";
            this.radSystem.UseVisualStyleBackColor = true;
            // 
            // radCyber
            // 
            this.radCyber.AutoSize = true;
            this.radCyber.Location = new System.Drawing.Point(31, 102);
            this.radCyber.Name = "radCyber";
            this.radCyber.Size = new System.Drawing.Size(117, 19);
            this.radCyber.TabIndex = 2;
            this.radCyber.TabStop = true;
            this.radCyber.Text = "Cybersecurity";
            this.radCyber.UseVisualStyleBackColor = true;
            // 
            // radNET
            // 
            this.radNET.AutoSize = true;
            this.radNET.Location = new System.Drawing.Point(31, 67);
            this.radNET.Name = "radNET";
            this.radNET.Size = new System.Drawing.Size(54, 19);
            this.radNET.TabIndex = 1;
            this.radNET.TabStop = true;
            this.radNET.Text = "NET";
            this.radNET.UseVisualStyleBackColor = true;
            // 
            // radCIT
            // 
            this.radCIT.AutoSize = true;
            this.radCIT.Location = new System.Drawing.Point(31, 36);
            this.radCIT.Name = "radCIT";
            this.radCIT.Size = new System.Drawing.Size(49, 19);
            this.radCIT.TabIndex = 0;
            this.radCIT.TabStop = true;
            this.radCIT.Text = "CIT";
            this.radCIT.UseVisualStyleBackColor = true;
            // 
            // btnEnter
            // 
            this.btnEnter.Location = new System.Drawing.Point(132, 165);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(91, 30);
            this.btnEnter.TabIndex = 5;
            this.btnEnter.Text = "&Enter";
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // lstOutput
            // 
            this.lstOutput.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstOutput.FormattingEnabled = true;
            this.lstOutput.ItemHeight = 18;
            this.lstOutput.Location = new System.Drawing.Point(35, 229);
            this.lstOutput.Name = "lstOutput";
            this.lstOutput.Size = new System.Drawing.Size(477, 130);
            this.lstOutput.TabIndex = 6;
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(53, 389);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(99, 26);
            this.btnDisplay.TabIndex = 7;
            this.btnDisplay.Text = "&Display";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // btnStats
            // 
            this.btnStats.Location = new System.Drawing.Point(171, 389);
            this.btnStats.Name = "btnStats";
            this.btnStats.Size = new System.Drawing.Size(99, 26);
            this.btnStats.TabIndex = 8;
            this.btnStats.Text = "&Stats";
            this.btnStats.UseVisualStyleBackColor = true;
            this.btnStats.Click += new System.EventHandler(this.btnStats_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(293, 389);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(93, 26);
            this.btnClear.TabIndex = 9;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(416, 389);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(95, 26);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(561, 447);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnStats);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.lstOutput);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.groupBox_Focus);
            this.Controls.Add(this.txtGPA);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblGPA);
            this.Controls.Add(this.lblName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HongUiryeom_Assignment10";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox_Focus.ResumeLayout(false);
            this.groupBox_Focus.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblGPA;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtGPA;
        private System.Windows.Forms.GroupBox groupBox_Focus;
        private System.Windows.Forms.RadioButton radSystem;
        private System.Windows.Forms.RadioButton radCyber;
        private System.Windows.Forms.RadioButton radNET;
        private System.Windows.Forms.RadioButton radCIT;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.ListBox lstOutput;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.Button btnStats;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
    }
}

