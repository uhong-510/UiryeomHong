﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

/*=========================================================
* Uiryeom Hong
* uhong@purdue.edu
* CNIT155 Assignment10
* Lab Section: Thurs. 11:30
* Program Description: The program taks data on  40 students of their last names, GPAs, and focus areas.
* It also provides how many students are in each focus area. 
* 
* Academic Honesty: 
*	I attest that this is my original work.
*	I have not used unauthorized source code, either modified or unmodified.
*	I have not given other fellow student(s) access to my program.
*=========================================================== */

namespace HongUiryeom_Assignment10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Class Scope Declarations
        private const int cSize = 40;
        private string[] mName = new string[cSize];
        private double[] mGPA = new double[cSize];
        private string[] mFocus = new string[cSize];
        private int mCIT = 0;
        private int mNET = 0;
        private int mCyber = 0;
        private int mSystem = 0;
        private int mIndex = 0;
        private string mFileName = Path.Combine(Application.StartupPath, "Students.txt");

        //Helper Method
        //ValidateInput()
        private bool ValidateInput()
        {
            //Name
            if (txtName.Text == "")
            {
                DisplayMessageOK("Please enter your name.");
                txtName.Focus();
                return false;
            }
            //GPA
            double GPA;
            if (double.TryParse(txtGPA.Text, out GPA) == false)
            {
                DisplayMessageOK("GPA must be a whole number.");
                txtGPA.Focus();
                return false;
            }
            if (0 > GPA || GPA > 4.0)
            {
                DisplayMessageOK("GPA must be a real number between 0 to 4.0.");
                txtGPA.Focus();
                return false;
            }
            //RadioButton
            if (radCIT.Checked == false && radCyber.Checked == false && radNET.Checked == false && radSystem.Checked == false)
            {
                DisplayMessageOK("One of the radio buttons must be selected.");
                return false;

            }

            return true;
        }

        //ClearInput
        private void ClearInput()
        {
            txtName.Clear();
            txtGPA.Clear();
            radCIT.Checked = false;
            radCyber.Checked = false;
            radNET.Checked = false;
            radSystem.Checked = false;
            txtName.Focus();
        }

        //DisplayMessageOK()
        private void DisplayMessageOK(string msg)
        {
            MessageBox.Show(msg, Text, MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            if (ValidateInput() == false)
            {
                return;
            }

            mName[mIndex] = txtName.Text;
            mGPA[mIndex] = double.Parse(txtGPA.Text);

            if (radCIT.Checked == true)
            {
                mFocus[mIndex] = "CIT";
                mCIT++;
            }
            else if (radNET.Checked == true)
            {
                mFocus[mIndex] = "NET";
                mNET++;
            }
            else if (radCyber.Checked == true)
            {
                mFocus[mIndex] = "Cybersecurity";
                mCyber++;
            }
            else
            {
                mFocus[mIndex] = "System";
                mSystem++;
            }

            mIndex++;

            if (mIndex == cSize)
            {
                DisplayMessageOK("Array is full.");
                btnEnter.Enabled = false;
            }

            ClearInput();

        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            if (mIndex == 0)
            {
                DisplayMessageOK("Array is empty.");
                btnEnter.Enabled = false;
            }

            lstOutput.Items.Clear();

            lstOutput.Items.Add("Name".PadRight(15) + "Focus".PadRight(20) + "GPA");
            lstOutput.Items.Add("=================================================");


            for (int ctr = 0; ctr < mIndex; ctr++)
            {
                lstOutput.Items.Add(mName[ctr].PadRight(15) + mFocus[ctr].PadRight(20) + mGPA[ctr].ToString("n"));
            }
        }

        private void btnStats_Click(object sender, EventArgs e)
        {
            lstOutput.Items.Clear();

            lstOutput.Items.Add("Number of Students in CIT = " + mCIT);
            lstOutput.Items.Add("Number of Students in NET = " + mNET);
            lstOutput.Items.Add("Number of Students in Cybersecurity = " + mCyber);
            lstOutput.Items.Add("Number of Students in System = " + mSystem);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearInput();
            lstOutput.Items.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            int ctr;
            StreamWriter SW = null;
            try
            {
                if (MessageBox.Show("Are you sure ? ", Text, MessageBoxButtons.YesNo,
                                                   MessageBoxIcon.Question) == DialogResult.No)
                {
                    e.Cancel = true;
                    return;
                }

                SW = new StreamWriter(mFileName);

                for (ctr = 0; ctr < mIndex; ctr++)
                {
                    SW.WriteLine(mName[ctr] + "\t" + mFocus[ctr] + "\t" + mGPA[ctr].ToString("n"));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (SW != null)
                {
                    SW.Close();
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            StreamReader SR = null;
            string line;
            string[] parts;
            try
            {
                if (File.Exists(mFileName) == false)
                {
                    MessageBox.Show("File does not exist.");
                    return;
                }

                SR = new StreamReader(mFileName);

                while (SR.Peek() != -1)
                {
                    line = SR.ReadLine();
                    parts = line.Split('\t');
                    mName[mIndex] = parts[0];
                    mFocus[mIndex] = parts[1];
                    mGPA[mIndex] = double.Parse(parts[2]);
                    mIndex++;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (SR != null)
                {
                    SR.Close();
                }
            }
        }
    }
}
