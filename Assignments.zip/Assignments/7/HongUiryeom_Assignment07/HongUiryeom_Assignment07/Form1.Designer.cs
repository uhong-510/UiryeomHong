﻿namespace HongUiryeom_Assignment07
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFullName = new System.Windows.Forms.Label();
            this.lblDays = new System.Windows.Forms.Label();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.txtDays = new System.Windows.Forms.TextBox();
            this.lstName = new System.Windows.Forms.ListBox();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radSquares = new System.Windows.Forms.RadioButton();
            this.radFactorial = new System.Windows.Forms.RadioButton();
            this.radOddCubes = new System.Windows.Forms.RadioButton();
            this.radPennies = new System.Windows.Forms.RadioButton();
            this.btnCompute = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblFullName
            // 
            this.lblFullName.AutoSize = true;
            this.lblFullName.Location = new System.Drawing.Point(33, 46);
            this.lblFullName.Name = "lblFullName";
            this.lblFullName.Size = new System.Drawing.Size(75, 15);
            this.lblFullName.TabIndex = 0;
            this.lblFullName.Text = "Full Name:";
            // 
            // lblDays
            // 
            this.lblDays.AutoSize = true;
            this.lblDays.Location = new System.Drawing.Point(48, 92);
            this.lblDays.Name = "lblDays";
            this.lblDays.Size = new System.Drawing.Size(46, 15);
            this.lblDays.TabIndex = 1;
            this.lblDays.Text = "Days:";
            // 
            // txtFullName
            // 
            this.txtFullName.Location = new System.Drawing.Point(114, 43);
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Size = new System.Drawing.Size(141, 25);
            this.txtFullName.TabIndex = 2;
            // 
            // txtDays
            // 
            this.txtDays.Location = new System.Drawing.Point(114, 89);
            this.txtDays.Name = "txtDays";
            this.txtDays.Size = new System.Drawing.Size(74, 25);
            this.txtDays.TabIndex = 3;
            // 
            // lstName
            // 
            this.lstName.FormattingEnabled = true;
            this.lstName.ItemHeight = 15;
            this.lstName.Location = new System.Drawing.Point(284, 30);
            this.lstName.Name = "lstName";
            this.lstName.Size = new System.Drawing.Size(208, 79);
            this.lstName.TabIndex = 4;
            // 
            // txtOutput
            // 
            this.txtOutput.Location = new System.Drawing.Point(30, 141);
            this.txtOutput.Multiline = true;
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.ReadOnly = true;
            this.txtOutput.Size = new System.Drawing.Size(461, 110);
            this.txtOutput.TabIndex = 5;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radPennies);
            this.groupBox1.Controls.Add(this.radOddCubes);
            this.groupBox1.Controls.Add(this.radFactorial);
            this.groupBox1.Controls.Add(this.radSquares);
            this.groupBox1.Location = new System.Drawing.Point(30, 268);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(461, 110);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Pay Options:";
            // 
            // radSquares
            // 
            this.radSquares.AutoSize = true;
            this.radSquares.Location = new System.Drawing.Point(23, 32);
            this.radSquares.Name = "radSquares";
            this.radSquares.Size = new System.Drawing.Size(134, 19);
            this.radSquares.TabIndex = 0;
            this.radSquares.TabStop = true;
            this.radSquares.Text = "Sum of Squares";
            this.radSquares.UseVisualStyleBackColor = true;
            // 
            // radFactorial
            // 
            this.radFactorial.AutoSize = true;
            this.radFactorial.Location = new System.Drawing.Point(23, 68);
            this.radFactorial.Name = "radFactorial";
            this.radFactorial.Size = new System.Drawing.Size(91, 19);
            this.radFactorial.TabIndex = 1;
            this.radFactorial.TabStop = true;
            this.radFactorial.Text = "Factorials";
            this.radFactorial.UseVisualStyleBackColor = true;
            // 
            // radOddCubes
            // 
            this.radOddCubes.AutoSize = true;
            this.radOddCubes.Location = new System.Drawing.Point(236, 32);
            this.radOddCubes.Name = "radOddCubes";
            this.radOddCubes.Size = new System.Drawing.Size(152, 19);
            this.radOddCubes.TabIndex = 2;
            this.radOddCubes.TabStop = true;
            this.radOddCubes.Text = "Sum of odd Cubes";
            this.radOddCubes.UseVisualStyleBackColor = true;
            // 
            // radPennies
            // 
            this.radPennies.AutoSize = true;
            this.radPennies.Location = new System.Drawing.Point(236, 68);
            this.radPennies.Name = "radPennies";
            this.radPennies.Size = new System.Drawing.Size(133, 19);
            this.radPennies.TabIndex = 3;
            this.radPennies.TabStop = true;
            this.radPennies.Text = "Sum of Pennies";
            this.radPennies.UseVisualStyleBackColor = true;
            // 
            // btnCompute
            // 
            this.btnCompute.Location = new System.Drawing.Point(53, 391);
            this.btnCompute.Name = "btnCompute";
            this.btnCompute.Size = new System.Drawing.Size(96, 26);
            this.btnCompute.TabIndex = 7;
            this.btnCompute.Text = "Compute";
            this.btnCompute.UseVisualStyleBackColor = true;
            this.btnCompute.Click += new System.EventHandler(this.btnCompute_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(193, 391);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(89, 25);
            this.btnClear.TabIndex = 8;
            this.btnClear.Text = "C&lear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(322, 391);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(96, 27);
            this.btnExit.TabIndex = 9;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(513, 443);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnCompute);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtOutput);
            this.Controls.Add(this.lstName);
            this.Controls.Add(this.txtDays);
            this.Controls.Add(this.txtFullName);
            this.Controls.Add(this.lblDays);
            this.Controls.Add(this.lblFullName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.Text = "HongUiryeom_Assignment07";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFullName;
        private System.Windows.Forms.Label lblDays;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.TextBox txtDays;
        private System.Windows.Forms.ListBox lstName;
        private System.Windows.Forms.TextBox txtOutput;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radPennies;
        private System.Windows.Forms.RadioButton radOddCubes;
        private System.Windows.Forms.RadioButton radFactorial;
        private System.Windows.Forms.RadioButton radSquares;
        private System.Windows.Forms.Button btnCompute;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
    }
}

