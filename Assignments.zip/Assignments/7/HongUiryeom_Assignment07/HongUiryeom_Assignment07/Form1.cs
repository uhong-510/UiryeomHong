﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*=========================================================
* Uiryeom Hong
* uhong@purdue.edu
* CNIT155 Assignment07
* Lab Section: Thurs. 11:30
* Program Description: The program provides 4 types of pay options. The user can choose any of them, but for factorial payment, 
* the number of employeed days have to be over 5 days. Each pay option shows how much the user can earn based on the employeed days.
* Through this program, the user can make a wise decision of what pay options is better. 
* Academic Honesty: 
*	I attest that this is my original work.
*	I have not used unauthorized source code, either modified or unmodified.
*	I have not given other fellow student(s) access to my program.
*=========================================================== */

namespace HongUiryeom_Assignment07
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCompute_Click(object sender, EventArgs e)
        {
            //Decalre needed variables
            String Method;
            int days = int.Parse(txtDays.Text);
            double pay = 0;
            String Name = "";
            Name = txtFullName.Text;
            lstName.Items.Add(Name);
    

            if (ValidateInput() == false)
            {
                return;
            }

            if (radSquares.Checked == true)
            {
                Method = "Sum Of Squares";
                int ctr;
                double sum = 0;
                for (ctr = 1; ctr <= days; ctr++)
                {
                    sum += ctr * ctr;
                    pay = sum;
                }
            }
            else if (radOddCubes.Checked == true)
            {
                Method = "Sum of Odd Cubes";
                int ctr;
                double sum = 0;
                for (ctr = 1; ctr <= days; ctr+=2)
                {
                    sum += Math.Pow(ctr, 3);
                    pay = sum;
                }
            }
            else if (radFactorial.Checked == true)
            {
                Method = "Factorial";

                int ctr;
                int Days = int.Parse(txtDays.Text);
                double sum = 1;
                for (ctr = 1; ctr <= days; ctr++)
                { 
                    sum = sum * ctr;
                    pay = sum;
                }
            }
            else
            {
                Method = "Sum of Pennies";
                int Days = int.Parse(txtDays.Text);
                double sum = SumOfPennies(Days);
                pay = sum / 100;
            }

            txtOutput.Text = "Dear " + Name + "," + "\r\n" +
                "You selected: " + Method + "\r\n" +
                "Days employeed: " + days + "\r\n" +
                "Pay: " + pay.ToString("c");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtFullName.Text = "";
            txtDays.Text = "";
            txtOutput.Text = "";

            radSquares.Checked = false;
            radFactorial.Checked = false;
            radOddCubes.Checked = false;
            radPennies.Checked = false;

            txtFullName.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        //Helper Method
        //DisplayMessage
        private void DisplayMessageOK(string msg)
        {
            MessageBox.Show(msg, Text, MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private bool ValidateInput()
        {
            //Full Name
            String FullName = txtFullName.Text;
            bool CheckSpace = FullName.Contains(" ");

            if (txtFullName.Text == "")
            {
                DisplayMessageOK("Name must be a full name");
                txtFullName.Focus();
                return false;
            }
            //FullNameSpace
            if (CheckSpace == false)
            {
                DisplayMessageOK("Name must be a full name");
                txtFullName.Focus();
                return false;
            }

            //Days
            int days = int.Parse(txtDays.Text);

            if (int.TryParse(txtDays.Text, out days) == false)
            {
                DisplayMessageOK("Days must be a whole number.");
                txtDays.Focus();
                return false;
            }
            if (days < 5 || days > 30)
            {
                DisplayMessageOK("Days must be in range of 5 to 30.");
                txtDays.Focus();
                return false;
            }

            //RadioButtons
            if (radSquares.Checked == false && radFactorial.Checked == false && radOddCubes.Checked == false && radPennies.Checked == false)
            {
                DisplayMessageOK("One of the Radio buttons must be selected.");
                return false;
            }
            if (radFactorial.Checked == true)
            {
                if (days > 9)
                {
                    DisplayMessageOK("If method of payment is Factorial, number of days must be less than 10.");
                    txtDays.Focus();
                    return false;
                }
            }
            return true;
        }

        //SumOfPennies
        private double SumOfPennies(int Days)
        {
            int ctr;
            double sum = 0;
            Days = int.Parse(txtDays.Text);

            for (ctr = 0; ctr < Days; ctr++)
            {
                sum = sum + Math.Pow(2, ctr);
            }

            return sum;
        }

    }
}
