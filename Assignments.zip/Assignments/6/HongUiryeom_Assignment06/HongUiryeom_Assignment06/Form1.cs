﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*************************************************************
* Uiryeom Hong
* uhong@purdue.edu
* CNIT155 Assignment06
* Lab Section: Thurs. 11:30
* Program Description: The program computes loans based on customer's duration of years.
* Based on the duration of years, the anuual interest rate varies. When the customer hits Stats button,
* it will show how many times that user compute loans and how much of loan amount has been processed. 
* Academic Honesty: 
*	I attest that this is my original work.
*	I have not used unauthorized source code, either modified or unmodified.
*	I have not given other fellow student(s) access to my program.
*************************************************************/

namespace HongUiryeom_Assignment06
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lblCustomerID_Click(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearInput();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnShowStats_Click(object sender, EventArgs e)
        {
            if (ValidateInput() == false)
            {
                return;
            }
            txtOutput.Text = "";
            txtOutput.Text = "Number of loans processed: " + loancount.ToString("") +"\r\n" +
                "Total loans processed: " + totalloan.ToString("c");
        }

        // Helper method
        //DisplayMessageOK()
        private void DisplayMessageOK(string msg)
        {
            MessageBox.Show(msg, Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        //ClearInput()
        private void ClearInput()
        {
            txtOutput.Text = "";
            txtFullName.Text = "";
            txtCustomerID.Text = "";
            txtLoanAmount.Text = "";
            cboduration.SelectedIndex = -1;
            loancount = 0;
            totalloan = 0;
            txtFullName.Focus();
        }

        //ValidateInput()
        private bool ValidateInput()
        {
            String FullName = txtFullName.Text;
            bool CheckSpace = FullName.Contains(" ");
            String CustomerID;
            CustomerID = txtCustomerID.Text;
            double LoanAmt;

        //Existence Check
            if (txtFullName.Text == "")
            {
                DisplayMessageOK("Name must be a full name");
                txtFullName.Focus();
                return false;
            }
            //FullName
            if (CheckSpace == false)
            {
                DisplayMessageOK("Name must be a full name");
                txtFullName.Focus();
                return false;
            }
            //ID Check
            if (CustomerID.Length != 6)
            {
                DisplayMessageOK("Customer's ID must be 6 digit number.");
                txtCustomerID.Focus();
                return false;
            }
            //Type Check
            if (txtLoanAmount.Text == "")
            {
                DisplayMessageOK("Loan amount must be a real number.");
                txtLoanAmount.Focus();
                return false;
            }
            if (double.TryParse(txtLoanAmount.Text, out LoanAmt) == false)
            {
                DisplayMessageOK("Loan amount must be a real number.");
                txtLoanAmount.Focus();
                return false;
            }
            //Range Check
            if (LoanAmt < 2000.00 || LoanAmt > 500000.00)
            {
                DisplayMessageOK("Loan amount must be greater than or equal to $2000 and less than or equal to $500,000.");
                txtLoanAmount.Focus();
                return false;
            }
            //ComboBox Selection
            if (cboduration.SelectedItem == null)
            {
                DisplayMessageOK("Duration of the loan must be selected from the ComboBox.");
                cboduration.Focus();
                return false;
            }
            return true;
        }


        //ComputePayment()
        double PMT;
        private double totalloan;
        private int loancount ;
        double loanamount;
        double years;
        double minterestrate;
        String duration;
        double ainterestrate;

        private double ComputePayment(double loanamount, double years, double minterestrate)
            {
            loanamount = double.Parse(txtLoanAmount.Text);
            years = double.Parse(cboduration.Text);
            minterestrate = (ainterestrate/12);
            PMT = (loanamount * minterestrate) / (1 - Math.Pow(1 + minterestrate, -(years * 12)));
            return PMT;
            }

        
        private void btnCompute_Click(object sender, EventArgs e)
            {
            duration =cboduration.Text;

            if (ValidateInput() == false)
            {
                return;
            }
            if (duration.Equals("10"))
            {
                ainterestrate = .0325;
            }
            if (duration.Equals("15"))
            {
                ainterestrate = .0350;
            }
            if (duration.Equals("20"))
            {
                ainterestrate = .0400;
            }
            if (duration.Equals("30"))
            {
                ainterestrate = .0450;
            }

            loancount++;
            double monthlypay;

            monthlypay = ComputePayment(loanamount, years, minterestrate);
            loanamount = double.Parse(txtLoanAmount.Text);
            totalloan = totalloan + loanamount;

            txtOutput.Text = "Customer: " + txtFullName.Text + "\r\n" +
                "Loan ID: " + txtCustomerID.Text + "\r\n" +
                "Loan Amount: " + loanamount.ToString("c") + "\r\n" +
                "Duration Of the loan: " + cboduration.Text + " years" + "\r\n" +
                "Annual Interest Rate: " + ainterestrate.ToString("P") + "\r\n" +
                "Montly payment: " + monthlypay.ToString("c");
        }
    }
}
