﻿namespace HongUiryeom_Assignment05
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txtCustomer = new System.Windows.Forms.TextBox();
            this.txtStems = new System.Windows.Forms.TextBox();
            this.txtZipcode = new System.Windows.Forms.TextBox();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.lblStems = new System.Windows.Forms.Label();
            this.lblZipcode = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radOrchids = new System.Windows.Forms.RadioButton();
            this.radTulips = new System.Windows.Forms.RadioButton();
            this.radRoses = new System.Windows.Forms.RadioButton();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.btnOrder = new System.Windows.Forms.Button();
            this.btnStats = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtCustomer
            // 
            this.txtCustomer.Location = new System.Drawing.Point(135, 74);
            this.txtCustomer.Name = "txtCustomer";
            this.txtCustomer.Size = new System.Drawing.Size(100, 25);
            this.txtCustomer.TabIndex = 0;
            // 
            // txtStems
            // 
            this.txtStems.Location = new System.Drawing.Point(135, 116);
            this.txtStems.Name = "txtStems";
            this.txtStems.Size = new System.Drawing.Size(100, 25);
            this.txtStems.TabIndex = 1;
            // 
            // txtZipcode
            // 
            this.txtZipcode.Location = new System.Drawing.Point(135, 160);
            this.txtZipcode.MaxLength = 5;
            this.txtZipcode.Name = "txtZipcode";
            this.txtZipcode.Size = new System.Drawing.Size(100, 25);
            this.txtZipcode.TabIndex = 2;
            this.txtZipcode.TextChanged += new System.EventHandler(this.txtZipcode_TextChanged);
            // 
            // lblCustomer
            // 
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.Location = new System.Drawing.Point(38, 77);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(74, 15);
            this.lblCustomer.TabIndex = 3;
            this.lblCustomer.Text = "Customer:";
            // 
            // lblStems
            // 
            this.lblStems.AutoSize = true;
            this.lblStems.Location = new System.Drawing.Point(38, 119);
            this.lblStems.Name = "lblStems";
            this.lblStems.Size = new System.Drawing.Size(79, 15);
            this.lblStems.TabIndex = 4;
            this.lblStems.Text = "# of Stems";
            // 
            // lblZipcode
            // 
            this.lblZipcode.AutoSize = true;
            this.lblZipcode.Location = new System.Drawing.Point(47, 163);
            this.lblZipcode.Name = "lblZipcode";
            this.lblZipcode.Size = new System.Drawing.Size(65, 15);
            this.lblZipcode.TabIndex = 5;
            this.lblZipcode.Text = "Zipcode:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radOrchids);
            this.groupBox1.Controls.Add(this.radTulips);
            this.groupBox1.Controls.Add(this.radRoses);
            this.groupBox1.Location = new System.Drawing.Point(286, 63);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(129, 137);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Flowers";
            // 
            // radOrchids
            // 
            this.radOrchids.AutoSize = true;
            this.radOrchids.Location = new System.Drawing.Point(7, 95);
            this.radOrchids.Name = "radOrchids";
            this.radOrchids.Size = new System.Drawing.Size(79, 19);
            this.radOrchids.TabIndex = 2;
            this.radOrchids.TabStop = true;
            this.radOrchids.Text = "Orchids";
            this.radOrchids.UseVisualStyleBackColor = true;
            // 
            // radTulips
            // 
            this.radTulips.AutoSize = true;
            this.radTulips.Location = new System.Drawing.Point(7, 59);
            this.radTulips.Name = "radTulips";
            this.radTulips.Size = new System.Drawing.Size(66, 19);
            this.radTulips.TabIndex = 1;
            this.radTulips.TabStop = true;
            this.radTulips.Text = "Tulips";
            this.radTulips.UseVisualStyleBackColor = true;
            // 
            // radRoses
            // 
            this.radRoses.AutoSize = true;
            this.radRoses.Location = new System.Drawing.Point(7, 25);
            this.radRoses.Name = "radRoses";
            this.radRoses.Size = new System.Drawing.Size(71, 19);
            this.radRoses.TabIndex = 0;
            this.radRoses.TabStop = true;
            this.radRoses.Text = "Roses";
            this.radRoses.UseVisualStyleBackColor = true;
            // 
            // txtOutput
            // 
            this.txtOutput.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOutput.Location = new System.Drawing.Point(13, 216);
            this.txtOutput.Multiline = true;
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.ReadOnly = true;
            this.txtOutput.Size = new System.Drawing.Size(429, 166);
            this.txtOutput.TabIndex = 7;
            // 
            // btnOrder
            // 
            this.btnOrder.Location = new System.Drawing.Point(70, 406);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(75, 23);
            this.btnOrder.TabIndex = 8;
            this.btnOrder.Text = "&Order";
            this.btnOrder.UseVisualStyleBackColor = true;
            this.btnOrder.Click += new System.EventHandler(this.btnOrder_Click);
            // 
            // btnStats
            // 
            this.btnStats.Location = new System.Drawing.Point(170, 406);
            this.btnStats.Name = "btnStats";
            this.btnStats.Size = new System.Drawing.Size(75, 23);
            this.btnStats.TabIndex = 9;
            this.btnStats.Text = "&Stats";
            this.btnStats.UseVisualStyleBackColor = true;
            this.btnStats.Click += new System.EventHandler(this.btnStats_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(270, 406);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 10;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(367, 406);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 11;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtTitle
            // 
            this.txtTitle.Font = new System.Drawing.Font("Malgun Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtTitle.Location = new System.Drawing.Point(135, 19);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.ReadOnly = true;
            this.txtTitle.Size = new System.Drawing.Size(266, 38);
            this.txtTitle.TabIndex = 3;
            this.txtTitle.Text = "Valentine\'s Flowers";
            this.txtTitle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtTitle.TextChanged += new System.EventHandler(this.txtTitle_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(17, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(454, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtTitle);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnStats);
            this.Controls.Add(this.btnOrder);
            this.Controls.Add(this.txtOutput);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblZipcode);
            this.Controls.Add(this.lblStems);
            this.Controls.Add(this.lblCustomer);
            this.Controls.Add(this.txtZipcode);
            this.Controls.Add(this.txtStems);
            this.Controls.Add(this.txtCustomer);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.Text = "HongUiryeom_Assignment05";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCustomer;
        private System.Windows.Forms.TextBox txtStems;
        private System.Windows.Forms.TextBox txtZipcode;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.Label lblStems;
        private System.Windows.Forms.Label lblZipcode;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radOrchids;
        private System.Windows.Forms.RadioButton radTulips;
        private System.Windows.Forms.RadioButton radRoses;
        private System.Windows.Forms.TextBox txtOutput;
        private System.Windows.Forms.Button btnOrder;
        private System.Windows.Forms.Button btnStats;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

