﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*=========================================================
* Uiryeom Hong
* uhong@purdue.edu
* CNIT155 Assignment05
* Lab Section: Thurs. 11:30
* Program Description: This program allows users to order three kinds of flowers. It shows the total price of the orders based on 
* numbers of flowers that user orders. The user can order as many flowers as user wants. It will show history of user's order when the user
* press stats button. Stats shows which and how many flowers that user ordered and how much is the total. The order button will only 
* show the price of flowers that user want to order. It also includes how much the user can have for discount when he/she ordered 12 or 24 stems, 
* and the user can see the price of flowers without tax and with tax. 
* Academic Honesty: 
*	I attest that this is my original work.
*	I have not used unauthorized source code, either modified or unmodified.
*	I have not given other fellow student(s) access to my program.
*=========================================================== */

namespace HongUiryeom_Assignment05
{ 
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtTitle_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCustomer.Text = "";
            txtStems.Text = "";
            txtZipcode.Text = "";
            txtOutput.Text = "";
            radRoses.Checked = false;
            radTulips.Checked = false;
            radOrchids.Checked = false;
            rcount = 0;
            tcount = 0;
            ocount = 0;
            Total = 0;
            txtCustomer.Focus();
        }

        private double Price = 0;
        private double Price_Rose = 4.50;
        private double Price_Tulips = 3.00;
        private double Price_Orchids = 7.00;
        private double Discount1 = 0.10;
        private double Discount2 = 0.20;
        private double Tax = 0.08;
        private double Discount_Price = 0;
        private double Tax_Price = 0;
        private double Total = 0;
        private double Price_Total = 0;
        private int stems;
        private String Result = "";
        private int rcount = 0;
        private int tcount = 0;
        private int ocount = 0;

        private void btnOrder_Click(object sender, EventArgs e)
        {
            //Existence Check
            if (txtCustomer.Text == "")
            {
                MessageBox.Show("Customer’s name must exist", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtCustomer.Focus();
                return;
            }

            //Type Check:  # of stems must be a whole number. 
            //Range check: Number of stems must be between 1 and 24, both inclusive.
            stems = int.Parse(txtStems.Text);

            if (int.TryParse(txtStems.Text, out stems) == false)
            {
                MessageBox.Show("# of stems must be a whole number", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtStems.Focus();
                return;
            }

            if  (stems < 1 || stems > 24)
            {
                MessageBox.Show("# of stems must be between 1 and 24", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtStems.Focus();
                return;
            }

            if (txtStems.Text == "")
            {
                MessageBox.Show("# of stems must entered", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtCustomer.Focus();
                return;
            }

            //The zip code must be a whole number.
            //The zip code must be 5 digits long.
            int zipcode;
            zipcode = int.Parse(txtZipcode.Text);
            String zip;
            zip = txtZipcode.Text;

            if (int.TryParse(txtZipcode.Text, out zipcode) == false)
            {
                MessageBox.Show("The zip code must be a whole number", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtZipcode.Focus();
                return;
            }

            if (zip.Length != 5)
            {
                MessageBox.Show("The zip code must be 5 digits long", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtZipcode.Focus();
                return;
            }

            if (txtZipcode.Text == "")
            {
                MessageBox.Show("The zipcode must be entered", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtZipcode.Focus();
                return;
            }

            //One of the radio buttons must be selected
            if (radRoses.Checked == false && radTulips.Checked == false && radOrchids.Checked == false)
            {
                MessageBox.Show("One of the flowers must be selected", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            if (radRoses.Checked)
            {
                Result = "Roses";
                rcount = stems + rcount;
                if (stems == 12)
                {
                    Discount_Price = (Price_Rose * stems) * Discount1;
                    Price = (Price_Rose * stems) - Discount_Price;
                    Tax_Price = Price + (Price * Tax);
                }
                else if (stems == 24)
                {
                    Discount_Price = (Price_Rose * stems) * Discount2;
                    Price = (Price_Rose * stems) - Discount_Price;
                    Tax_Price = Price + (Price * Tax);
                }
                else
                {
                    Price = Price_Rose * stems;
                    Tax_Price = Price + (Price * Tax);
                }
            }
            else if (radTulips.Checked)
            {
                Result = "Tulips";
                tcount = tcount + stems;
                if (stems == 12)
                {
                    Discount_Price = (Price_Tulips * stems) * Discount1;
                    Price = (Price_Tulips * stems) - Discount_Price;
                    Tax_Price = Price + (Price * Tax);
                }
                else if (stems == 24)
                {
                    Discount_Price = (Price_Tulips * stems) * Discount2;
                    Price = (Price_Tulips * stems) - Discount_Price;
                    Tax_Price = Price + (Price * Tax);
                }
                else
                {
                    Price = Price_Tulips * stems;
                    Tax_Price = Price + (Price * Tax);
                }
            }
            else if (radOrchids.Checked)
            {
                Result = "Orchids";
                ocount = ocount + stems;
                if (stems == 12)
                {
                    Discount_Price = (Price_Orchids * stems) * Discount1;
                    Price = (Price_Orchids * stems) - Discount_Price;
                    Tax_Price = Price + (Price * Tax);
                }
                else if (stems == 24)
                {
                    Discount_Price = (Price_Orchids * stems) * Discount2;
                    Price = (Price_Orchids * stems) - Discount_Price;
                    Tax_Price = Price + (Price * Tax);
                }
                else
                {
                    Price = Price_Orchids * stems;
                    Tax_Price = Price + (Price * Tax);
                }
            }
            Price_Total = Tax_Price;
            Total = Price_Total + Total;
           
            txtOutput.Text = "Customer: " + txtCustomer.Text + "\r\n" +
                "Ordered " + stems + " stems of " + Result + "\r\n" +
                "Zipcode: " + zipcode + "\r\n" +
                "Discount: " + Discount_Price.ToString("c") + "\r\n" +
                "Price Before tax: " + Price.ToString("c") + "\r\n" +
                "Prcie Plus tax: " + Tax_Price.ToString("c") + "\r\n";

        }

        private void btnStats_Click(object sender, EventArgs e)
        {
            txtOutput.Text = "Number of Roses ordered = " + rcount.ToString("") + "\r\n" +
                "Number of Tulips ordered = " + tcount.ToString("") + "\r\n" +
                "Number of Orchids orders = " + ocount.ToString("") + "\r\n" +
                "Total Sales Made = " + Total.ToString("c");
        }

        private void txtZipcode_TextChanged(object sender, EventArgs e)
        {
         
        }
    }
}
