﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/******************************************************************************
 * Uiryeom(Caroline) Hong
 * uhong@purdue.edu
 * CNIT155Assignment02
 * Lab Section: Thur.11:30
 * Program Description:
 * 
 * Academic Honesty: 
 *      I attest that this is my orginial work.
 *      I have not used unauthorized source code, either modified or unmodified.
 *      I have not given other fellow student(s) access to my program.
 *******************************************************************************/
 
namespace HongUiryeom_Assignment02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtFirstname_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSummary_Click(object sender, EventArgs e)
        {
            txtOutput.Text = "Full Name: " + txtFirstname.Text + txtLastname.Text + "\r\n" + "First Name: " + txtFirstname.Text + "\r\n" + "Last Name: " + txtLastname.Text + "\r\n"
                + "User Name: " + txtusername.Text + "\r\n" + "Email: " + txtusername.Text + "@purdue.edu" + "\r\n" + "Phone Number : " + "(" + txtareacode.Text + ")" + " " + txtlinenumber.Text;

        }

        private void btnFullname_Click(object sender, EventArgs e)
        {
            txtOutput.Text = "The student's full name is " + txtFirstname.Text + " " + txtLastname.Text + ".";
        }

        private void btnContact_Click(object sender, EventArgs e)
        {
            txtOutput.Text = txtFirstname.Text + " " + txtLastname.Text + " can be contacted by either phone " + "(" + txtareacode.Text + ") " + " " + txtlinenumber.Text + " or by email " + txtusername.Text + "@purdue.edu.";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
        }

        private void btnClear_Click_1(object sender, EventArgs e)
        {
            txtOutput.Text = "";
            txtFirstname.Text = "";
            txtLastname.Text = "";
            txtusername.Text = "";
            txtareacode.Text = "";
            txtlinenumber.Text = "";
            txtFirstname.Focus();
        }
    }
}
