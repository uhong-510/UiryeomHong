﻿namespace HongUiryeom_Assignment03
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtF1 = new System.Windows.Forms.TextBox();
            this.txtF2 = new System.Windows.Forms.TextBox();
            this.txtF3 = new System.Windows.Forms.TextBox();
            this.txtF4 = new System.Windows.Forms.TextBox();
            this.txtC1 = new System.Windows.Forms.TextBox();
            this.txtC2 = new System.Windows.Forms.TextBox();
            this.txtC3 = new System.Windows.Forms.TextBox();
            this.txtC4 = new System.Windows.Forms.TextBox();
            this.btnMeanFahrenheit = new System.Windows.Forms.Button();
            this.btnConvertFtoC = new System.Windows.Forms.Button();
            this.btnSDFahrenheit = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnConvertCtoF = new System.Windows.Forms.Button();
            this.btnSDCelsius = new System.Windows.Forms.Button();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(74, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Fahrenheit";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(74, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "F-1:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(74, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "F-2:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(74, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "F-3:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(74, 190);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(25, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "F-4:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(269, 66);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Celsius";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(269, 98);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "C-1:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(269, 130);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(26, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "C-2:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(269, 161);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "C-3:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(269, 190);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(26, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "C-4:";
            // 
            // txtF1
            // 
            this.txtF1.Location = new System.Drawing.Point(105, 95);
            this.txtF1.Name = "txtF1";
            this.txtF1.Size = new System.Drawing.Size(100, 20);
            this.txtF1.TabIndex = 10;
            // 
            // txtF2
            // 
            this.txtF2.Location = new System.Drawing.Point(105, 127);
            this.txtF2.Name = "txtF2";
            this.txtF2.Size = new System.Drawing.Size(100, 20);
            this.txtF2.TabIndex = 11;
            // 
            // txtF3
            // 
            this.txtF3.Location = new System.Drawing.Point(105, 158);
            this.txtF3.Name = "txtF3";
            this.txtF3.Size = new System.Drawing.Size(100, 20);
            this.txtF3.TabIndex = 12;
            // 
            // txtF4
            // 
            this.txtF4.Location = new System.Drawing.Point(105, 187);
            this.txtF4.Name = "txtF4";
            this.txtF4.Size = new System.Drawing.Size(100, 20);
            this.txtF4.TabIndex = 13;
            // 
            // txtC1
            // 
            this.txtC1.Location = new System.Drawing.Point(302, 95);
            this.txtC1.Name = "txtC1";
            this.txtC1.Size = new System.Drawing.Size(100, 20);
            this.txtC1.TabIndex = 14;
            // 
            // txtC2
            // 
            this.txtC2.Location = new System.Drawing.Point(302, 127);
            this.txtC2.Name = "txtC2";
            this.txtC2.Size = new System.Drawing.Size(100, 20);
            this.txtC2.TabIndex = 15;
            // 
            // txtC3
            // 
            this.txtC3.Location = new System.Drawing.Point(302, 158);
            this.txtC3.Name = "txtC3";
            this.txtC3.Size = new System.Drawing.Size(100, 20);
            this.txtC3.TabIndex = 16;
            // 
            // txtC4
            // 
            this.txtC4.Location = new System.Drawing.Point(302, 187);
            this.txtC4.Name = "txtC4";
            this.txtC4.Size = new System.Drawing.Size(100, 20);
            this.txtC4.TabIndex = 17;
            // 
            // btnMeanFahrenheit
            // 
            this.btnMeanFahrenheit.Location = new System.Drawing.Point(86, 225);
            this.btnMeanFahrenheit.Name = "btnMeanFahrenheit";
            this.btnMeanFahrenheit.Size = new System.Drawing.Size(119, 23);
            this.btnMeanFahrenheit.TabIndex = 18;
            this.btnMeanFahrenheit.Text = "&Mean Fahrenheit";
            this.btnMeanFahrenheit.UseVisualStyleBackColor = true;
            this.btnMeanFahrenheit.Click += new System.EventHandler(this.btnMeanFahrenheit_Click);
            // 
            // btnConvertFtoC
            // 
            this.btnConvertFtoC.Location = new System.Drawing.Point(86, 254);
            this.btnConvertFtoC.Name = "btnConvertFtoC";
            this.btnConvertFtoC.Size = new System.Drawing.Size(119, 23);
            this.btnConvertFtoC.TabIndex = 19;
            this.btnConvertFtoC.Text = "&Convert F to C";
            this.btnConvertFtoC.UseVisualStyleBackColor = true;
            this.btnConvertFtoC.Click += new System.EventHandler(this.btnConvertFtoC_Click);
            // 
            // btnSDFahrenheit
            // 
            this.btnSDFahrenheit.Location = new System.Drawing.Point(86, 284);
            this.btnSDFahrenheit.Name = "btnSDFahrenheit";
            this.btnSDFahrenheit.Size = new System.Drawing.Size(119, 23);
            this.btnSDFahrenheit.TabIndex = 20;
            this.btnSDFahrenheit.Text = "SD &Fahrenheit";
            this.btnSDFahrenheit.UseVisualStyleBackColor = true;
            this.btnSDFahrenheit.Click += new System.EventHandler(this.btnSDFahrenheit_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(283, 225);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 23);
            this.button1.TabIndex = 21;
            this.button1.Text = "Mea&n Celcius";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnConvertCtoF
            // 
            this.btnConvertCtoF.Location = new System.Drawing.Point(283, 253);
            this.btnConvertCtoF.Name = "btnConvertCtoF";
            this.btnConvertCtoF.Size = new System.Drawing.Size(119, 23);
            this.btnConvertCtoF.TabIndex = 22;
            this.btnConvertCtoF.Text = "C&onvert C to F";
            this.btnConvertCtoF.UseVisualStyleBackColor = true;
            this.btnConvertCtoF.Click += new System.EventHandler(this.btnConvertCtoF_Click);
            // 
            // btnSDCelsius
            // 
            this.btnSDCelsius.Location = new System.Drawing.Point(283, 283);
            this.btnSDCelsius.Name = "btnSDCelsius";
            this.btnSDCelsius.Size = new System.Drawing.Size(119, 23);
            this.btnSDCelsius.TabIndex = 23;
            this.btnSDCelsius.Text = "SD C&elsius";
            this.btnSDCelsius.UseVisualStyleBackColor = true;
            this.btnSDCelsius.Click += new System.EventHandler(this.btnSDCelsius_Click);
            // 
            // txtOutput
            // 
            this.txtOutput.Location = new System.Drawing.Point(77, 335);
            this.txtOutput.Multiline = true;
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.ReadOnly = true;
            this.txtOutput.Size = new System.Drawing.Size(325, 125);
            this.txtOutput.TabIndex = 24;
            this.txtOutput.TextChanged += new System.EventHandler(this.txtOutput_TextChanged);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(246, 499);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 25;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(327, 499);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 26;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(525, 598);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txtOutput);
            this.Controls.Add(this.btnSDCelsius);
            this.Controls.Add(this.btnConvertCtoF);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnSDFahrenheit);
            this.Controls.Add(this.btnConvertFtoC);
            this.Controls.Add(this.btnMeanFahrenheit);
            this.Controls.Add(this.txtC4);
            this.Controls.Add(this.txtC3);
            this.Controls.Add(this.txtC2);
            this.Controls.Add(this.txtC1);
            this.Controls.Add(this.txtF4);
            this.Controls.Add(this.txtF3);
            this.Controls.Add(this.txtF2);
            this.Controls.Add(this.txtF1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "HongUiryeom_Assignment03";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtF1;
        private System.Windows.Forms.TextBox txtF2;
        private System.Windows.Forms.TextBox txtF3;
        private System.Windows.Forms.TextBox txtF4;
        private System.Windows.Forms.TextBox txtC1;
        private System.Windows.Forms.TextBox txtC2;
        private System.Windows.Forms.TextBox txtC3;
        private System.Windows.Forms.TextBox txtC4;
        private System.Windows.Forms.Button btnMeanFahrenheit;
        private System.Windows.Forms.Button btnConvertFtoC;
        private System.Windows.Forms.Button btnSDFahrenheit;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnConvertCtoF;
        private System.Windows.Forms.Button btnSDCelsius;
        private System.Windows.Forms.TextBox txtOutput;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
    }
}

