﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/******************************************************************************
 * Uiryeom(Caroline) Hong
 * uhong@purdue.edu
 * CNIT155Assignment03
 * Lab Section: Thur.11:30
 * Program Description: It converts each Fahrenheit degrees to Celcius degrees and converts from Celcius degrees to Fahrenheit degrees.
 * It also calculates mean of Fahrenheit degrees and mean of Celcius, and it calculate standard deviation of Fahrenheit and Celsius. 
 * Academic Honesty: 
 *      I attest that this is my orginial work.
 *      I have not used unauthorized source code, either modified or unmodified.
 *      I have not given other fellow student(s) access to my program.
 *******************************************************************************/

namespace HongUiryeom_Assignment03
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtF1.Text = "";
            txtF2.Text = "";
            txtF3.Text = "";
            txtF4.Text = "";
            txtC1.Text = "";
            txtC2.Text = "";
            txtC3.Text = "";
            txtC4.Text = "";
            txtOutput.Text = "";
            txtF1.Focus();
        }

        private void btnMeanFahrenheit_Click(object sender, EventArgs e)
        {
            double F1;
            double F2;
            double F3;
            double F4;

            F1 = double.Parse(txtF1.Text);
            F2 = double.Parse(txtF2.Text);
            F3 = double.Parse(txtF3.Text);
            F4 = double.Parse(txtF4.Text);
            double mean = (F1 + F2 + F3 + F4) / 4.00;

            txtOutput.Text = "The mean FAH Temperature = " + mean.ToString("n");
        }

        private void txtOutput_TextChanged(object sender, EventArgs e)
        {
         
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double C1;
            double C2;
            double C3;
            double C4;

            C1 = double.Parse(txtC1.Text);
            C2 = double.Parse(txtC2.Text);
            C3 = double.Parse(txtC3.Text);
            C4 = double.Parse(txtC4.Text);
            double mean = (C1 + C2 + C3 + C4) / 4.00;

            txtOutput.Text = "The mean CEL Temperature = " + mean.ToString("n");
        }

        private void btnConvertFtoC_Click(object sender, EventArgs e)
        {
            double F1;
            double F2;
            double F3;
            double F4;

            F1 = double.Parse(txtF1.Text);
            F2 = double.Parse(txtF2.Text);
            F3 = double.Parse(txtF3.Text);
            F4 = double.Parse(txtF4.Text);

            double StartingTemp1, ResultTemp1;
            StartingTemp1 = double.Parse(txtF1.Text);
            ResultTemp1 = (StartingTemp1 - 32)*(5.0 / 9);
            txtC1.Text = ResultTemp1.ToString("n");

            double StartingTemp2, ResultTemp2;
            StartingTemp2 = double.Parse(txtF2.Text);
            ResultTemp2 = (StartingTemp2 - 32) * (5.0 / 9);
            txtC2.Text = ResultTemp2.ToString("n");

            double StartingTemp3, ResultTemp3;
            StartingTemp3 = double.Parse(txtF3.Text);
            ResultTemp3 = (StartingTemp3 - 32) * (5.0 / 9);
            txtC3.Text = ResultTemp3.ToString("n");

            double StartingTemp4, ResultTemp4;
            StartingTemp4 = double.Parse(txtF4.Text);
            ResultTemp4 = (5.0 / 9) * (StartingTemp4 - 32);
            txtC4.Text = ResultTemp4.ToString("n");

            double mean = (F1 + F2 + F3 + F4) / 4.00;
            txtOutput.Text = "The mean FAH Temperature = " + mean.ToString("n");

        }

        private void btnConvertCtoF_Click(object sender, EventArgs e)
        {
            double C1;
            double C2;
            double C3;
            double C4;

            C1 = double.Parse(txtC1.Text);
            C2 = double.Parse(txtC2.Text);
            C3 = double.Parse(txtC3.Text);
            C4 = double.Parse(txtC4.Text);

            double StartingTemp1, ResultTemp1;
            StartingTemp1 = double.Parse(txtC1.Text);
            ResultTemp1 = ((9.0 / 5) * StartingTemp1) + 32;
            txtF1.Text = ResultTemp1.ToString("n");

            double StartingTemp2, ResultTemp2;
            StartingTemp2 = double.Parse(txtC2.Text);
            ResultTemp2 = ((9.0 / 5) * StartingTemp2) + 32;
            txtF2.Text = ResultTemp2.ToString("n");

            double StartingTemp3, ResultTemp3;
            StartingTemp3 = double.Parse(txtC3.Text);
            ResultTemp3 = ((9.0 / 5) * StartingTemp3) + 32;
            txtF3.Text = ResultTemp3.ToString("n");

            double StartingTemp4, ResultTemp4;
            StartingTemp4 = double.Parse(txtC4.Text);
            ResultTemp4 = ((9.0 / 5) * StartingTemp4) + 32;
            txtF4.Text = ResultTemp4.ToString("n");

            double mean = (C1 + C2 + C3 + C4) / 4.00;

            txtOutput.Text = "The mean CEL Temperature = " + mean.ToString("n");
        }

        private void btnSDFahrenheit_Click(object sender, EventArgs e)
        {
            double F1;
            double F2;
            double F3;
            double F4;

            F1 = double.Parse(txtF1.Text);
            F2 = double.Parse(txtF2.Text);
            F3 = double.Parse(txtF3.Text);
            F4 = double.Parse(txtF4.Text);

            double mean = (F1 + F2 + F3 + F4) / 4.00;
            double sum = Math.Abs(Math.Pow(F1 - mean, 2)) + (Math.Pow(F2 - mean, 2)) + (Math.Pow(F3 - mean, 2)) + (Math.Pow(F4 - mean, 2));
            double n = 4.00;
            double SD = (sum / n);
            double Answer = Math.Sqrt(SD);

            txtOutput.Text = "The SD of FAH temperatures = " + Answer.ToString("n");

            txtC1.Text = "";
            txtC2.Text = "";
            txtC3.Text = "";
            txtC4.Text = "";
        }

        private void btnSDCelsius_Click(object sender, EventArgs e)
        {
            double C1;
            double C2;
            double C3;
            double C4;

            C1 = double.Parse(txtC1.Text);
            C2 = double.Parse(txtC2.Text);
            C3 = double.Parse(txtC3.Text);
            C4 = double.Parse(txtC4.Text);

            double mean = (C1 + C2 + C3 + C4) / 4.00;
            double sum = Math.Abs(Math.Pow(C1 - mean, 2)) + (Math.Pow(C2 - mean, 2)) + (Math.Pow(C3 - mean, 2)) + (Math.Pow(C4 - mean, 2));
            double n = 4.00;
            double SD = (sum / n);
            double Answer = Math.Sqrt(SD);

            txtOutput.Text = "The SD of CEL temperatures = " + Answer.ToString("n");

            txtF1.Text = "";
            txtF2.Text = "";
            txtF3.Text = "";
            txtF4.Text = "";
        }
    }
}
