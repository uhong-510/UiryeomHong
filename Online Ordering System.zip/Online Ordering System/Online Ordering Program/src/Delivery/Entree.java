/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Delivery;

/**
 *
 * @author ryannapastrana
 */
public class Entree implements Storage
{
    public double staticPrice = 14.99;
    
    @Override
    public double totalUnitPrice(double chosenQuantity)
    {
        double totalPrice;
        totalPrice = staticPrice * chosenQuantity;
        return totalPrice;
    }
    
    public Entree()
    {
        return;
    }
}
