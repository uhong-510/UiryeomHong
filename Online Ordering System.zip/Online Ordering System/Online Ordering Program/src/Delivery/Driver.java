/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Delivery;

/**
 *
 * @author ryannapastrana
 */
/*public class Driver extends Car
 */
public class Driver extends Car
{
    public String driverName = "Adam";
    
	public Driver ()
    {
    	return;
    }

}
